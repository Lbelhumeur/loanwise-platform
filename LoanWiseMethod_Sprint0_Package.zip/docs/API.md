GET /courses
GET /lessons/{id}
POST /progress
POST /notes