frontend/
backend/
infrastructure/
course-content/
docs/
.github/