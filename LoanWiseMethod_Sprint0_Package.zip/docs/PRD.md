# PRD
Cloud-native LMS with Cognito, S3 content, DynamoDB user data.