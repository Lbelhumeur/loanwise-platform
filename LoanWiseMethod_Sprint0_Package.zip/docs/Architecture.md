# Architecture
Route53->CloudFront->S3(React)->Cognito->API Gateway->Lambda->DynamoDB/S3.